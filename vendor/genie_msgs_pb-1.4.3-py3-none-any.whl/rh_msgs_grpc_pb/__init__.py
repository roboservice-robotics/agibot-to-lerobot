# Auto-generated __init__.py file
# Imports all modules in this package
from .operator_event_service_pb2 import *
from .config_robot_service_pb2 import *

__all__ = ['operator_event_service_pb2', 'config_robot_service_pb2']